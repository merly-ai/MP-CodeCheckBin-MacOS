// Copyright (c) 2022-23 Urs C. Muff, Justin Gottschlich, Merly, Inc.
var selected_item = -1;
var list_count = 0;
var hover_on = true;
var href_store = {};
var chart_store = {};
var chart_csv_store = {};
var repo_user_access = new Set();
var compare_selections = new Set();
var curr_tab_id = 'mentor_summaries_tab';

// repo search and filtering vars
var repo_search_entries = {};
var repo_score_filter_entries = {};
var repo_language_filter_entries = {};
var repo_row_ids = new Set();
var selected_languages = new Set();
var repo_search_results = new Set();
var repo_score_filter_results = new Set();
var repo_language_filter_results = new Set();
var repo_list_charts = [];

var cur_chart_date = null;
function setup_chart(id, on_click_href, href_post = '', clickable = true) {
  var chartDom = document.getElementById(id);
  var chart = echarts.init(chartDom, 'dark', { renderer: 'svg' });

  chart_store[id] = chart;

  if (id.includes("current-score-")) {
    repo_list_charts.push(chart);
  }

  if (!id.includes("-gauge")) {
    // Only add click event listeners if the clickable parameter is true
    if (clickable) {
      chart.on('click', function(params) {
        // Print name in console
        do_open(on_click_href + '/' + params.name + href_post);
      });

      chart.getZr().on('click', function(event) {
        if (cur_chart_date && event.offsetY > 120) {
          // debugger;
          do_open(on_click_href + '/' + cur_chart_date + href_post);
        }
      });
    } else {
      // Set the cursor style to 'not-allowed' when the chart is not clickable
      chart.getZr().configLayer(0, {
        cursor: 'not-allowed'
      });
    }

    chart.setOption({
      toolbox: {
        feature: {
          dataView: {
            show: true,
            optionToContent: function (opt) {
              return setup_chart_csv(id, opt);
            }
          }
        }
      },
      axisPointer: {
        label: {
          formatter: function (value) {
            if (value.axisDimension == 'x') {
              cur_chart_date = value.value;
            } else if (value.axisDimension == 'y') {
              value.value = value.axisIndex == 0 ? 
                value.value.toFixed(1) :
                Math.round(value.value);
            }
            return value.value;
          }
        }
      }
    });
  }

  window.addEventListener("resize", function () { chart.resize(); });
}

function setup_chart_csv(id, opt) {
  var table = '<button class="csv-button" onclick="' +
    'download_chart_csv(\'' + id + '\')">Export as CSV</button>' +
    '<div class="data-view">' +
    '<table class="data-view-table"><tbody>';
  var csv = '';

  var series = opt.series;

  // instance author chart
  if (!opt.xAxis && opt.series.length > 0) {
    table += '<tr><td>Contributor</td><td>Commit</td></tr>';
    csv += 'Contributor,Commit\n';
    
    for (var i = 0; i < series[0].data.length; i++) {
      table += '<tr><td>' + series[0].data[i].name + '</td>';
      table += '<td>' + series[0].data[i].value + '</td></tr>';
      csv += series[0].data[i].name + ',' + series[0].data[i].value + '\n';
    }
  }
  
  // lifetime performance + author timeline charts
  else {
    var axisData = opt.xAxis[0].data;

    var row_count = axisData.length;
    var col_count = series.length;
    
    // table header
    table += '<tr><td>Instance</td>'
    csv += 'Instance,';
    for (var c = 0; c < col_count; c++) {
      table += '<td>' + series[c].name + '</td>';
      csv += series[c].name;
      if (c < col_count - 1) csv += ',';
    }
    table += '</tr>'
    csv += '\n';

    // table rows
    for (var r = 0; r < row_count; r++) {
      table += '<tr>';
      table += '<td>' + axisData[r] + '</td>';
      csv += axisData[r] + ',';

      for (var c = 0; c < col_count; c++) {
        table += '<td>' + series[c].data[r] + '</td>';
        csv += series[c].data[r];
        if (c < col_count - 1) csv += ',';
      }
      table += '</tr>';
      csv += '\n';
    }
  }

  table += '</tbody></table></div>';

  chart_csv_store[id] = csv;

  return table;
}

function download_chart_csv(id) {
  download_csv(id, chart_csv_store[id]);
}

async function download_table_csv(id) {
  let response = await fetch('/csv/' + id);
  if (response.ok) {
    let data = await response.text();
    download_csv(id, data);
  } else {
    console.log('Could not download CSV', response);
  }
}

function download_csv(id, data) {
  const blob = new Blob([data], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  const ext = id === 'configuration' ? '.json' : '.csv';
  a.setAttribute('href', url);
  a.setAttribute('download', id + ext)
  a.click();
}

async function get_chart_data(url, chart_id) {
  var chart = chart_store[chart_id];
  let response = await fetch(url);
  let data = await response.json();

  // set gauge value to zero so that
  // gauge animation plays properly
  var gauge_val = data.series[0]?.data[0]?.value ?? "0";
  if (chart_id.includes('-gauge')) {
    data.series[0].data[0].value = 0;
  }

  // add legend tooltips to lifetime overview chart
  if (chart_id.includes('lifetime-overview')) {
    data.legend.tooltip = {
      show: true,
      showContent: true,
      formatter: function (params) {
        switch (params.name) {
          case "AIL":
            return "Average Issues per 10k LoC";
          case "SR":
            return "Score Ratio";
          case "New/Qt":
            return "New Issues per Quarter";
          case "Rem/Qt":
            return "Removed Issues per Quarter";
          case "LoC":
            return "Lines of Code";
          default:
            return params.name;
        }
      },
    };
  }
  
  chart.setOption(data);
  unselectGraph(chart, 'New/Qt');
  unselectGraph(chart, 'Rem/Qt');
  unselectGraph(chart, 'Issues');
  unselectGraph(chart, 'Mentor Score');

  // set gauge value back to original
  // value to animate gauge
  if (chart_id.includes('-gauge')) {
    data.series[0].data[0].value = gauge_val;
    chart.setOption(data);
  }

  chart.resize();
}

function unselectGraph(chart, name) {
  chart.dispatchAction({
    type: 'legendUnSelect',
    name: name,
  })
}

function create_UUID() {
  var dt = new Date().getTime();
  var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = (dt + Math.random()*16)%16 | 0;
    dt = Math.floor(dt/16);
    return (c=='x' ? r :(r&0x3|0x8)).toString(16);
  });
  // console.log("create_UUID: " + uuid);
  return uuid;
}

function getCook(cookiename)  {
  var cookiestring = RegExp(cookiename + "=[^;]+").exec(document.cookie);
  return decodeURIComponent(!!cookiestring ? cookiestring.toString().replace(/^[^=]+./,"") : "");
}

function store_UUID() {
  // console.log("store_UUID");
  if (!localStorage.getItem('uuid'))
    localStorage.setItem('uuid', create_UUID());

  var uuid = localStorage.getItem('uuid');
  // console.log("storage: uuid=" + uuid);

  var uuid_elm = document.getElementById('uuid');
  if (uuid_elm) {
    // console.log("set uuid_elm.value");
    uuid_elm.innerText = uuid;
  }
  // else console.log("missing uuid_elm");

  // console.log("previous cookie: " + document.cookie);
  var old_uuid = getCook('uuid');
  document.cookie = "uuid=" + uuid;
  if (window.location.pathname == "/" || window.location.href.includes('/welcome'))
    return;
  if (!old_uuid)
    window.open("/", "_self");
}

var current_session = null;
var stop_timer = false;
var key = "$CUST_ID$";
var user_id = 0;
var lost = 0;

async function get_session() {
  try {
    let response = await fetch('/json/session');
    let data = await response.json();
    if (data) {
      current_session = data;
      user_id = parseInt(data.user_id);
      localStorage.setItem('user_id', user_id);
      lost = 0;
      // console.log("key", key, "user_id", user_id);
    }
    else if (++lost > 2) {
      if (parseInt(localStorage.getItem('user_id'))) {
        localStorage.setItem('user_id', 0);
        console.log("lost session");
        current_session = null;
        window.setTimeout(() => { window.open("/", "_self"); }, 10000);
      }
    }
  }
  catch (e) {
    if (++lost > 2) {
      if (parseInt(localStorage.getItem('user_id'))) {
        localStorage.setItem('user_id', 0);
        console.log("lost session");
        current_session = null;
        window.setTimeout(() => { window.open("/", "_self"); }, 10000);
      }
    }
  }
}

async function activity_req(t = 10) {
  setTimeout(() => {
    if (!user_id)
      user_id = parseInt(localStorage.getItem('user_id'));
    if (!user_id)
      user_id = 0;
    try { fetch("https://merlyserviceadmin.azurewebsites.net/api/activity?key=" + key + "&user_id=" + str(user_id) + "&type=" + t + "&counter=1", { mode: 'no-cors' }); }
    catch (e) {}
  }, 100);
}

window.addEventListener("DOMContentLoaded", function() {
  var outer = document.getElementById("outer");
  outer.lastMouseMoveTime = 0;
  outer.addEventListener("mousemove", element => {
    var currentTime = new Date().getTime();
    if (currentTime - outer.lastMouseMoveTime > 300000) {
      activity_req(31);
      outer.lastMouseMoveTime = currentTime;
    }
  });
});

function start_timer() {
  function timer_callback() {
    get_session();
    if (!stop_timer)
      window.setTimeout(start_timer, 5000);
  }
  window.setTimeout(timer_callback, 5000);
}

async function replace_html(id, url) {
  // console.log(['replace_html', id, url]);
  show_dialog(processing, 'replace_html_process', 'modal-robot', "replace_html(" + id + ", " + url + ")");
  let response = await fetch(url);
  let html = await response.text();
  remove_el('replace_html_process');
  key_handlers_on = !url.includes('edit');
  if (html) {
    // replace outer html if cancelling add new repo
    if (id === '#') {
      let add_repo = document.getElementById('repo-search-and-add-repo-area');
      add_repo.outerHTML = html;
      setup_repo_search();
      setup_repo_score_filter();
      setup_repo_language_filter();
    }

    // replace inner html otherwise
    else {
      set_inner(id, html);
    }
  }
  else console.log(url, 'Empty HTML');
}

function replace_txt(id, txt, url, pre = '- ', post = '') {
  // console.log(['replace_txt', id, txt, url, pre, post]);
  set_inner(id, `${pre}<a href="#" onclick="replace_html('${id}', '${url}')">${txt}</a>${post}`);
  key_handlers_on = !url.includes('edit');
  // console.log(e.innerHTML);
}

function open_id(url, repo, date, ID, target = '_self') {
  localStorage.setItem('action', 'show_insight');
  localStorage.setItem('repo', repo);
  localStorage.setItem('date', date);
  localStorage.setItem('ID', ID);
  // show_dialog(processing, 'dialog', 'modal-robot', "open_id(" + url + ")");
  window.open(url, target);
}

function do_open(url, target = '_self') {
  // show_dialog(processing, 'dialog', 'modal-robot', "do_open(" + url + ")");
  window.open(url, target);
}

function do_reload() {
  // show_dialog(processing, 'dialog', 'modal-robot', "do_reload()");
  location.reload();
}

async function del_request(event, url) {
  if (event) event.preventDefault();
  // console.log(['del_request', url]);
  show_dialog(processing, 'del_process', 'modal-robot', "del_request(" + url + ")");
  let response = await fetch(url, { method: 'DELETE', redirect: 'follow' });
  if (response.redirected) {
    // console.log(['del_request', 'redirect', url, response.url]);
    // debugger;
    window.open(response.url, "_self");
    return;
  }
  let result = await response.text();
  remove_el('del_process');
  // console.log(['del_request', 'txt', url, result]);
}

async function update_job(button, html, job_key) {
  let job_state_resp = await fetch('/json/job?job_key=' + job_key);
  let job_state = await job_state_resp.json();
  var state = job_state['state'];
  var inner = '&nbsp;' + state + '&nbsp;<br/>&nbsp;duration=' + job_state['duration'] + '&nbsp;';
  if ('finished' in job_state) inner += '<br/>&nbsp;finished=' + job_state['finished'] + '&nbsp;';
  button.innerHTML = inner;
  if (state == 'running')
    wait_for_job_update(button, html, job_key);
  else
    setTimeout(() => do_reload(), 5000);
}

async function wait_for_job_update(button, html, job_key) {
  setTimeout(() => update_job(button, html, job_key), 500);
}

var next_job_id = 0;
async function post_job(event, url) {
  console.log(url);
  event.preventDefault();
  var button = url.includes('infer_points') ? document.getElementById('infer-points-button') : event.currentTarget;
  var html = button.outerHTML;
  ++next_job_id;
  var job_id = 'job-' + next_job_id;
  button.outerHTML = '<span id="' + job_id + '">Processing...</span>';
  button = document.getElementById(job_id);
  show_dialog(processing, 'post_progress', 'modal-robot', "post_job(" + url + ")");
  let response = await fetch(url, { method: 'POST' });
  const contentType = response.headers.get('content-type');
  if (contentType && contentType.includes('application/json')) {
    let result = await response.json();
    remove_el('post_progress');
    let job_key = result['job_key'];
    wait_for_job_update(button, html, job_key);
  } else {
    let result = await response.text();
    button.innderHTML = text;
    setTimeout(() => button.outerHTML = html, 5000);
  }
}

async function process_infer(job_key) {
  remove_el('dialog');
  var button = document.getElementById('infer-button');
  var html = button.outerHTML;
  ++next_job_id;
  var job_id = 'job-' + next_job_id;
  button.outerHTML = '<span id="' + job_id + '">Processing...</span>';
  button = document.getElementById(job_id);
  wait_for_job_update(button, html, job_key);
}

async function post_request(event, url) {
  event.preventDefault();
  if (event.currentTarget.nodeName == "BUTTON")
    event.currentTarget.outerHTML = '<span>Processing...</span>';
  // console.log(['post_request', url]);
  show_dialog(processing, 'post_progress', 'modal-robot', "post_request(" + url + ")");
  let response = await fetch(url, { method: 'POST' });
  if (response.redirected) {
    // console.log(['post_request', 'redirect', url, response.url]);
    // debugger;
    do_open(response.url, "_self");
    return;
  }
  const contentType = response.headers.get('content-type');
  if (contentType && contentType.includes('application/json')) {
    let result = await response.json();
    remove_el('post_progress');
    if ('action' in result) { eval(result['action']); }
  } else {
    let result = await response.text();
    remove_el('post_progress');
    // console.log(['post_request', 'txt', url, result]);
  }
}

function set_top_height(height) {
  var r = document.querySelector(':root');
  r.style.setProperty('--top-height', height);
}

function make_tooltips() {
  const tips = document.querySelectorAll(".tooltip");
  tips.forEach(tip => 
    {
      var ttts = tip.getElementsByTagName('ttt');
      if (ttts.length > 0)
        ttts[0].onmouseover = event => get_tooltip(event, tip)
      else
        tip.onmouseover = event => get_tooltip(event, tip)
    });

  const action = localStorage.getItem('action');
  if (action) {
    if (action == 'show_insight') {
      var repo = localStorage.getItem('repo');
      var date = localStorage.getItem('date');
      var ID = localStorage.getItem('ID');
      show_insight(repo, date, ID);
    }
    localStorage.removeItem('action');
  }
  const insightMode = localStorage.getItem('insightMode');
  if (insightMode)
    insightSelectedMode = insightMode;
}

var cur_tip = null;
var cur_edit = false;

function set_status(e, s, field = 'status') {
  var old = e.getAttribute(field);
  e.setAttribute(field, s);
  // console.log(field + ': ' + old + ' => ' + s);
}
function tip_info(t) { return "url=" + t.getAttribute('tooltip-url') + ", status=" + t.getAttribute('status'); }

function get_tooltip(event, t = null) {
  if (event.ctrlKey || event.shiftKey || event.altKey || cur_edit) return;
  if (t == null)
    t = event.currentTarget;
  if (!t.hasAttribute('tooltip-url')) { console.log("get_tooltip: " + t + ", missing tooltip-url"); debugger; return; }

  const url = t.getAttribute('tooltip-url');
  if (cur_tip != null) {
    if (url != cur_tip.getAttribute('tooltip-url')) console.log("get_tooltip-cur: " + tip_info(cur_tip) + ", skipping " + url);
    return;
  }

  var data = t.getElementsByClassName('data');
  if (data.length === 0) {
    var e = document.createElement("div");
    e.className = 'data';
    var cls = t.getAttribute('tool-class');
    if (cls) e.classList.add(cls);
    e.innerHTML = 'Loading';
    e.setAttribute('tooltip-url', t.getAttribute('tooltip-url'));
    e.setAttribute('status', 'cancel');
    t.appendChild(e);
    data = t.getElementsByClassName('data');
  }
  var tip = data[0];

  t.onmouseleave = event => {
    if (cur_edit) return;
    const tip = t.getElementsByClassName('data')[0];
    // console.log("tooltip-t-leave: " + tip_info(tip));
    const status = tip.getAttribute('status');
    if (status == 'enter' || status == 'loaded-enter') return;
    set_status(tip, 'cancel');
    cur_tip = null;
    setTimeout(() => {
      // console.log("tooltip-t-leave-hide: " + tip_info(tip));
      tip.innerHTML = 'Loading';
      tip.classList.remove("show");
    }, 500);
  };

  tip.onmouseenter = event => {
    if (cur_edit) return;
    const status = tip.getAttribute('status');
    if (status == 'loaded' || status == 'loaded-enter') set_status(tip, 'loaded-enter');
    else if (status == 'loading' || status == 'loading-enter') set_status(tip, 'loading-enter');
    else set_status(tip, 'enter');
    // console.log('tip-mouse-enter: ' + tip_info(tip));
  };
  tip.onmouseleave = event => {
    if (cur_edit) return;
    // console.log("tooltip-tip-leave");
    cur_tip = null;
    // const status = tip.getAttribute('status');
    set_status(tip, 'cancel');
    setTimeout(() => {
      // console.log("tooltip-tip-leave-hide: " + tip_info(tip));
      tip.innerHTML = 'Loading';
      tip.classList.remove("show");
    }, 500);
  };

  const status = tip.hasAttribute('status') ? tip.getAttribute('status') : 'cancel';
  if (status != 'cancel') {
    if (status == 'loaded' || status == 'loaded-enter') {
      cur_tip = tip;
      set_status(tip, 'loaded');
      console.log("tooltip: status: loaded (reuse), " + tip_info(tip));
      tip.classList.add("show");
      return;
    }
    if (status != 'loading' && status != 'loading=enter') console.log("tooltip: status: " + status + ", ignore, " + tip_info(tip));
    return;
  }
  if (status == 'enter') set_status(tip, 'loading-enter');
  else set_status(tip, 'loading');
  // console.log("tooltip: " + tip_info(tip) + " in 200");
  setTimeout(() => load_tooltip(tip), 200);
}

async function load_tooltip(tip) {
  if (cur_edit) return;
  var status = tip.getAttribute('status');
  if (status != 'loading' && status != 'loading-enter') {
    if (status != 'cancel') console.log("load_tooltip: " + tip_info(tip) + ", not loading, aborting");
    return;
  }
  const url = tip.getAttribute('tooltip-url');
  if (!url) { console.log("load_tooltip: " + tip_info(tip) + ", tooltip-url missing"); return; }

  // console.log("load_tooltip: request: " + tip_info(tip));
  if (cur_tip) { set_status(cur_tip, 'cancel'); cur_tip.classList.remove("show"); }
  cur_tip = tip;
  const response = await fetch(url);
  if (cur_edit) return;
  status = tip.getAttribute('status');
  if (status != 'loading' && status != 'loading-enter') {
    if (status != 'cancel') console.log("load_tooltip: " + status + ", not loading, aborting (2), " + tip_info(tip));
    return;
  }
  const html = await response.text();
  if (cur_edit) return;
  status = tip.getAttribute('status');
  if (status != 'loading' && status != 'loading-enter') {
    if (status != 'cancel') console.log("load_tooltip: " + status + ", not loading, aborting (3), " + tip_info(tip));
    return;
  }

  tip.classList.add("show");
  tip.innerHTML = html;

  status = tip.getAttribute('status');
  if (status == 'enter') set_status(tip, 'loaded-enter');
  else set_status(tip, 'loaded');
  // console.log("load_tooltip complete: " + tip_info(tip));
  // make_autoinput();
}

function make_autoinput() {
  var ins = document.querySelectorAll(".auto-input");
  ins.forEach(i => {
    if (i.innerText == '') i.innerText = i.getAttribute('default-value');
    i.onclick = event => switch_input(event);
  });
  ins = document.querySelectorAll(".in");
  ins.forEach(i => {
    i.addEventListener("focusout", event => submit_form(event));
    /* i.onchange = event => submit_form(event); */
  });
}

function submit_input(i) {
  var s = i.parentElement.children[0];
  i.style.visibility = 'hidden';
  i.style.padding = 0;
  i.style.height = 0;
  s.style.visibility = 'visible';
  s.style.height = '22px';
  let v = i.value;
  if (i.tagName == 'SELECT') {
    for (let ndx = 0; ndx < i.options.length; ndx++) {
        let o = i.options[ndx];
        if (o.value == v) {
            v = o.text;
            break;
        }
    }
  }
  s.innerText = v;
  if (s.innerText == '') s.innerText = s.getAttribute('default-value');
}

function submit_form(event) {
  var i = event.currentTarget;
  submit_input(i);

  var url = s.getAttribute('url');
  var name = i.getAttribute('name');
  console.log(["submit_form", url, name, i.value]);
  if (url) {
    let formData = new FormData();
    formData.append(name, i.value)
    submit_data(url, formData)
  } else {
    console.log(["submit", name, i.value]);
  }
}

function start_auto_input(event) {
  cur_edit = true;
  var a_href = event.currentTarget;
  a_href.onclick = event => {
    var url = event.currentTarget.getAttribute('url');
    let formData = new FormData();

    var ins = document.querySelectorAll(".auto-input");
    ins.forEach(s => {
      let i = s.parentElement.getElementsByClassName('in')[0];
      submit_input(i);
      var name = i.getAttribute('name');
      console.log(["data", name, i.value]);
      formData.append(name, i.value)
    });

    submit_data(url, formData);
    event.currentTarget.onclick = event => start_auto_input(event);
    a_href.lastChild.src = "/edit.svg";
    cur_edit = false;
    setTimeout(() => do_reload(), 500);
  };
  a_href.lastChild.src = "/save.svg";

  var ins = document.querySelectorAll(".auto-input");
  ins.forEach(i => {
    if (i.innerText == '') i.innerText = i.getAttribute('default-value');
    switch_input_(i, false);
  });
}

function switch_input(event) {
  switch_input_(event.currentTarget, true);
}

function switch_input_(s, set_focus = true) {
  var i = s.parentElement.getElementsByClassName('in')[0];
  var v = s.innerText;
  if (v.startsWith('<')) v = '';
  if (i.tagName == 'SELECT') {
    for (let ndx = 0; ndx < i.options.length; ndx++) {
      let o = i.options[ndx];
      if (o.text == v) {
        v = o.value;
        break;
      }
    }
  }
  i.value = v;
  s.style.visibility = 'hidden';
  s.style.height = 0;
  i.style.visibility = 'visible';
  i.style.height = '22px';
  i.style.padding = 2;
  if (set_focus) i.focus();
  // TODO: it would be nice to auto-open the dropdown so that not a second click is needed
  // if (i.tagName == 'SELECT') i.size = 8 * i.options.length;
}

async function form_submit(event, url, resp_id = null) {
  event.preventDefault();
  // console.log(['form_submit', event, url]);
  var formElem = event.target;
  if (formElem.form) formElem = formElem.form;

  let formData = new FormData(formElem);
  submit_data(url, formData, resp_id);
}

async function submit_data(url, data, resp_id = null) {
  show_dialog(processing, 'form_submit', 'modal-robot', "submit_data(" + url + ")");
  for (var pair of data.entries()) console.log('data: ' + pair[0] + ' = ' + pair[1]); 

  try
  {
    let response = await fetch(url, { method: 'POST', body: data });
    
    // update repo privileges
    if (response.ok && url.includes('/repo/post/')) {
      let repo_name = data.get('name');
      await post_repo_privs(repo_name, data);
    }

    if (response.redirected) {
      do_open(response.url, "_self");
      return;
    }

    const contentType = response.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
      let result = await response.json();
      remove_el('form_submit');
      if (result) {
        if ('action' in result) eval(result['action']);
        if ('txt'    in result) set_inner(resp_id, result['txt']);
      }
    } else {
      const result = await response.text();
      remove_el('form_submit');
      // console.log(['form_submit', 'txt', url, result]);
      set_inner(resp_id, result);
      var resp_e = document.getElementById(resp_id);
      if (!result.startsWith("<span")) {
        var viewId = resp_e.getAttribute('viewId');
        var viewUrl = resp_e.getAttribute('viewUrl');
        if (viewId && viewUrl)
          replace_html(viewId, viewUrl);
      }
    }
  }
  catch (e) {
    remove_el('form_submit');
  }
}

function set_inner(id, html) {
  if (!id) return;
  let e = document.getElementById(id);
  if (e) {
    e.innerHTML = html;
    var scripts = Array.prototype.slice.call(e.getElementsByTagName("script"));
    for (var i = 0; i < scripts.length; i++)
      eval(scripts[i].innerHTML);
  }
  else
    console.log('missing id: ' + id);
}

async function lic_download(event, url = '/lic_download/post', status_id = 'lic_status', lic_id = 'lic', info_id = 'form-resp') {
  if (event) event.preventDefault();
  var formElem = event.target;
  if (!formElem) { console.error(["unable to form", event.target]); return; }
  formElem = formElem.form;
  show_dialog(processing, 'lic_process', 'modal-robot', "lic_download(" + url + ")");
  let formData = new FormData(formElem);
  let response = await fetch(url, { method: 'POST', body: formData });
  let result = await response.json();
  set_inner(status_id, 'status' in result ? result['status'] : "<span 'bad_bg'>&nbsp;Missing Status&nbsp;</span>");
  set_inner(lic_id, 'lic' in result ? result['lic'] : "");
  set_inner(info_id, 'info' in result ? result['info'] : "");
  remove_el('lic_process');
}

let dialog_timeout;
function show_dialog(html, id = 'dialog', cls = 'modal', why = '') {
  var dialog = document.getElementById(id);
  if (dialog) dialog.parentElement.removeChild(dialog);
  dialog = document.createElement("div");
  dialog.id = id;
  dialog.className = cls;
  dialog.innerHTML = html;
  document.body.appendChild(dialog);
  if (html == processing) {
    dialog_timeout = window.setTimeout(() => {
      console.log("timeout", why);
      remove_el(id);
      do_reload();
    }, 120000);
  }
  return dialog;
}

var fetching = `<fieldset><legend> [ Mentor ] </legend>Fetching...</fieldset>`;
var processing = `<table class="rounded-table"><thead><tr><th> 
<img src="/r2_robot.svg" height="10px" />
.. Thinking .. 
<img src="/crazy_robot.svg" height="10px" />
</th></tr></thead></table>`;

async function get_dialog(event, url, id = 'dialog') {
  if (event) event.preventDefault();
  // console.log(['get_dialog', event, url]);
  show_dialog(fetching, id);
  let response = await fetch(url);
  let result = await response.text();
  // console.log(['get_dialog', 'txt', url, result]);
  key_handlers_on = false;
  show_dialog(result, id);
}

async function get_delete_confirm_dialog(event, what, delete_url) {
  if (event) event.preventDefault();
  show_dialog(fetching, 'delete-confirm-dialog');
  let response = await fetch('/partial/delete_confirm');
  let result = await response.text();
  key_handlers_on = false;

  result = result.replace('$WHAT$', what);
  if (what.length > 0) what = what.charAt(0).toLowerCase() + what.slice(1);
  result = result.replace('$WHAT$', what);
  result = result.replace('$DELETE_URL$', delete_url);

  show_dialog(result, 'delete-confirm-dialog');
}

function remove_el(id = 'dialog') {
  if (dialog_timeout) {
    window.clearTimeout(dialog_timeout);
    dialog_timeout = null;
  }
  var el = document.getElementById(id);
  if (el) el.parentElement.removeChild(el);
  if (id === 'dialog') {
    var el1 = document.getElementById('delete-confirm-dialog');
    if (el1) el1.parentElement.removeChild(el1);
  }
}

function select_first(id = 'list') {
  var list = document.getElementById(id);
  if (!list) {
    console.log("no list element found");
    return;
  }
  var items = list.getElementsByTagName('tr');
  var ndx = 0;
  for (item of items) {
    if (item.getElementsByTagName('th').length > 0) continue;
    item.id = 'I' + ndx;
    item.onmouseover = hover_link;
    ++ndx;
  }
  list_count = ndx;
  // console.log("list has %i items", list_count);
  var item = document.getElementById('I0');
  if (!item) {
    console.log("I0 not found");
    return;
  }
  selected_item = 0;
  item.classList.add('select');
}

function add_hover_(list) {
  if (!list) return;
  for (item of list.getElementsByTagName('tr')) {
    if (item.getElementsByTagName('th').length > 0) continue;

    var href = item.id ? href_store[item.id] : null;
    item.onmouseover = hover_link;
    for (a of item.getElementsByTagName('a')) {
      a.style.display = 'block';
      if (href) a.href = href;
    }
  }
}

function add_hover() {
  // console.log('add_hover');
  var pme = document.getElementById('paste_mode_id');
  if (pme) pme.innerText = '';
  hover_on = true;
  for (list of document.getElementsByClassName('list'))
    add_hover_(list);
  add_hover_(document.getElementById('list'));
}

function remove_hover_(list) {
  if (!list) return;
  for (item of list.getElementsByTagName('tr')) {
    if (item.getElementsByTagName('th').length > 0) continue;
    item.onmouseover = 'return false';
    for (a of item.getElementsByTagName('a')) {
      a.style.display = 'inline';
      a.draggable = false;
      if (item.id) href_store[item.id] = a.href;
      a.removeAttribute("href");
    }
  }
}

function remove_hover() {
  // console.log('remove_hover');
  var pme = document.getElementById('paste_mode_id');
  if (pme) pme.innerText = 'Copy/(P)aste Mode';
  hover_on = false;
  for (list of document.getElementsByClassName('list'))
    remove_hover_(list);
  remove_hover_(document.getElementById('list'));
}

function toggle_paste() {
  if (hover_on) remove_hover();
  else add_hover();
}

function toggle_popup(id) {
  var popup = document.getElementById(id);
  popup.classList.toggle("show");
}

function unselect_current() {
  if (selected_item < 0) return false;
  for (c of document.getElementsByClassName('select'))
    c.classList.remove('select');
  return true;
}

function select_current() {
  if (selected_item < 0) selected_item = 0;
  else if (selected_item >= list_count - 1) selected_item = list_count - 1;
  var item = document.getElementById('I' + selected_item);
  item.classList.add('select');
  item.scrollIntoView();
}

function select_previous() {
  if (!unselect_current()) return;
  --selected_item;
  select_current();
}

function follow_selected(ctrl) {
  if (selected_item < 0) {
    console.log("no item selected");
    return;
  }
  var links = document.getElementById('I' + selected_item).getElementsByTagName('a');
  if (!links || links.length < 1) {
    console.log("no links found in selected item");
    return;
  }
  do_open(links[0].href, ctrl ? "_blank" : "_self");
}

function hover_link(e) {
  // console.log("hover: currentTarget: %s, id=%s", e.currentTarget.id, id);
  for (c of document.getElementsByClassName('select'))
    c.classList.remove('select');
  e.currentTarget.classList.add('select');
  selected_item = e.currentTarget.id ? Number(e.currentTarget.id.substring(1)) : -1
}

key_handlers = {};
shift_key_handlers = {};
key_handlers_on = true;

function add_key_handler(which, handler) { key_handlers[which] = handler; }
function add_shift_key_handler(which, handler) { shift_key_handlers[which] = handler; }

function get_selected_expr() {
  var item = document.getElementById('I' + selected_item);
  if (!item) { console.log("item not found", selected_item); return null; }
  for (td of item.getElementsByTagName('td')) {
    if (td.id && td.id.startsWith('E')) {
      // console.log("td.id", td.id);
      return td.id;
    }
  }
  console.log("no td.id not found", item);
  return null;
}

async function post_dialog_action(url) {
  // console.log("post_dialog_action", url);
  show_dialog(processing, 'post_dialog_process', 'modal-robot', "post_dialog_action(" + url + ")");
  let response = await fetch(url, { method: 'POST' });
  // console.log("post_dialog_action : ", response);
  let result = await response.json();
  remove_el('post_dialog_process');
  // console.log("post_dialog_action <<", result);
  if ('html' in result) {
    let dialog = show_dialog(result['html']);
    window.setTimeout(() => {
      dialog.parentElement.removeChild(dialog);
      do_open(result['url']);
    }, 5000);
  } else if ('url' in result) {
    do_open(result['url']);
  }
}

function learn(what) {
  var e = get_selected_expr();
  if (!e) return;
  post_dialog_action("/learn_" + what + "/post/" + e);
}

async function do_filter(e, what, reload = true) {
  if (reload) show_dialog(processing, 'filter_process', 'modal-robot', "do_filter(" + what + ")");
  await post_request(e, "/filter/post/" + what);
  if (reload) do_reload();
}

async function do_detect_lang(e, repo) {
  show_dialog(processing, 'detect_process', 'modal-robot', "do_detect_lang(" + repo + ")");
  await post_request(e, "/detect_lang/post/" + encodeURIComponent(repo));
  do_reload();
}

function add_known_handlers() {
  // G            Learn Good Pattern
  // H            Learn Good Unique
  // P            Known Bad Pattern
  // O            Learn Bad Unique
  // R            Remove Known Entry
  // ,/.          Add / Sub Cost by 100
  // m            Reset Cost Filter to 0
  // 1-5          Filter by Complexity
  // s            Sort by Location / by Score

  // add_shift_key_handler(71, e => learn("good_pattern"));  // 'G'
  // add_shift_key_handler(72, e => learn("good_unique"));   // 'H'
  // add_shift_key_handler(80, e => learn("bad_pattern"));   // 'P'
  // add_shift_key_handler(79, e => learn("bad_unique"));    // 'O'
  // add_shift_key_handler(82, e => learn("remove"));        // 'R'

  // add_key_handler(188, e => do_filter(e, "dec_cost"));    // ','
  // add_key_handler(190, e => do_filter(e, "inc_cost"));    // '.'
  // add_key_handler( 77, e => do_filter(e, "reset"));       // 'm'
  // add_key_handler( 83, e => do_filter(e, "toggle_sort")); // 's'
}

function setup_key_handler() {
  // add_key_handler(80, e => toggle_paste());
  // add_key_handler( 8, e => history.back());
  // add_key_handler(13, e => follow_selected(e.ctrlKey));
  // add_key_handler(36, e => { if (!unselect_current()) return; selected_item = 0;              select_current(); }); // home
  // add_key_handler(35, e => { if (!unselect_current()) return; selected_item = list_count - 1; select_current(); }); // end
  // add_key_handler(33, e => { if (!unselect_current()) return; selected_item -= 20;            select_current(); }); // page-up
  // add_key_handler(34, e => { if (!unselect_current()) return; selected_item += 20;            select_current(); }); // page-down
  add_key_handler(38, e => { if (!unselect_current()) return; --selected_item;                select_current(); }); // up-arrow
  add_key_handler(40, e => { if (!unselect_current()) return; ++selected_item;                select_current(); }); // down-arrow
  
  document.addEventListener('keydown', function(e) {
    if (!key_handlers_on) return;
    let key = String.fromCharCode(e.which);

    // show chart tooltips when ctrl is pressed
    // if (e.which == 17) toggle_chart_tooltips(true);

    let is_left_right_arrow = e.which == 37 || e.which == 39;
    if (hover_on && is_left_right_arrow) {
      let target = document.getElementById("key-" + key)
      if (!target) target = document.getElementById("key-" + e.which)
      if (!e.shiftKey && !e.ctrlKey && target) {
        e.preventDefault();
        show_dialog(processing, 'dialog', 'modal-robot', "key-down(" + target + ")");
        if (typeof target.onclick == "function")
          target.onclick.apply(target);
        else if (target.href)
          window.open(target.href, e.ctrlKey ? "_blank" : "_self");
        return;
      }
    }

    if (!e.shiftKey && !e.ctrlKey && e.which in key_handlers) {
      e.preventDefault();
      if (e.which != 80 && !hover_on) return;
      key_handlers[e.which](e);
      return;
    }
    if (!hover_on) return;
    if (e.shiftKey && !e.ctrlKey && e.which in shift_key_handlers) {
      e.preventDefault();
      shift_key_handlers[e.which](e);
      return;
    }

    // debugger;
    return;
  });

  // document.addEventListener('keyup', function(e) {
  //   // hide chart tooltips when ctrl is released
  //   if (e.which == 17) toggle_chart_tooltips(false);
  // });
}

function toggle_chart_tooltips(show) {
  for (let [_, chart] of Object.entries(chart_store)) {
    chart.setOption({
      tooltip: {
        showContent: show,
      },
    });
  }
}

function generate_password(id) {
  let pwd = document.getElementById(id);

  let len = 12 + Math.floor(Math.random() * 12);
  let g = "";
  while (len-- > 0)
  {
    switch (Math.floor(Math.random() * 9))
    {
    case 0: case 1: case 2: // lower 
      g += String.fromCharCode('a'.charCodeAt(0) + Math.floor(Math.random() * 26));
      break;
    case 3: case 4: case 5: // upper
      g += String.fromCharCode('A'.charCodeAt(0) + Math.floor(Math.random() * 26));
      break;
    case 6: case 7:         // number
      g += String.fromCharCode('0'.charCodeAt(0) + Math.floor(Math.random() * 10));
      break;
    case 8: default: // symbol
      switch (Math.floor(Math.random() * 13))
      {
      case 0:  g += '~'; break;
      case 1:  g += '@'; break;
      case 2:  g += '#'; break;
      case 3:  g += '$'; break;
      case 4:  g += '%'; break;
      case 5:  g += '^'; break;
      case 6:  g += '&'; break;
      case 7:  g += '*'; break;
      case 8:  g += '('; break;
      case 9:  g += ')'; break;
      case 10: g += '-'; break;
      case 11: g += '+'; break;
      default: g += '='; break;
      }
    }
  }

  pwd.value = g;
  pwd.type = "text";
}

function enable_button(id) {
  let e = document.getElementById(id);
  if (e) e.disabled = false;
}

function new_user_input_changed(event) {
  var formElem = event.target;
  if (formElem.form) formElem = formElem.form;

  let formData = new FormData(formElem);
  if (formData.get('name') && formData.get('email')) {
    enable_button('add');
    enable_button('send');
  }
}

function send_email(event = nil) {
  form_submit(event, '/email/post/', 'form-resp');
}

/* Insights */
let insightContainer;
let insightContent;
let insightRoot;
let insightPrevButton;
let insightNextButton;
let insightRepoName;
let insightRepoPoint;
let insightID;
let insightPages;
let insightCurrentPageIndex = 0;
let insightMode;
let insightSelectedMode = "option1";
let privacyToggleInput;
let insightRequest = 0;

function handleSliderChange(event) {
  setInsightMode(event.target.id);
}

function setInsightMode(mode) {
  insightSelectedMode = mode;
  document.getElementById(mode).checked = true;

  const circle = document.querySelector('.circle');
  switch (insightSelectedMode) {
    case 'option1':
      circle.style.backgroundColor = '#57a64a';
      break;
    case 'option2':
      circle.style.backgroundColor = '#dcdca8';
      break;
    case 'option3':
      circle.style.backgroundColor = '#ff6c6c';
      break;
  }

  // console.log("Selected option:", insightSelectedMode);
  if (insightID) {
    if (!insightID.startsWith("F"))
      show_insight(insightRepoName, insightRepoPoint, insightID);
    else
      show_blockInsight(insightRepoName, insightRepoPoint, insightID.substr(1));
  }
}

function setup_insight() {
  if (!insightContainer) {
    // console.log("setup_insight");
    insightContainer = document.getElementById("insight-container");
    insightContent = document.getElementById("insight-content");
    insightRoot = insightContent;
    insightPrevButton = document.getElementById("insight-prev");
    insightNextButton = document.getElementById("insight-next");
    privacyToggleInput = document.getElementById('privacy-toggle-input');

    insightPages = [];
    insightCurrentPageIndex = 0;
    updateInsightNavigationButtons();

    if (!insightPrevButton.onclick)
      insightPrevButton.onclick = event => {
        if (insightCurrentPageIndex > 0) {
          insightCurrentPageIndex--;
          updateInsightContent();
        }
        updateInsightNavigationButtons();
      };

    if (!insightNextButton.onclick)
      insightNextButton.onclick = event => {
        if (insightCurrentPageIndex < insightPages.length - 1) {
          insightCurrentPageIndex++;
          updateInsightContent();
        }
        updateInsightNavigationButtons();
      };
  }
}

async function show_insight(repo_name, point, ID, hasPublic = false) {
  if (hasPublic) {
    setInsightMode("option3");
  }
  if (insightRepoName == repo_name && insightRepoPoint == point && insightID == ID && insightMode == insightSelectedMode)
  {
    // console.log("skip, request e-insight: ", repo_name, point, ID, insightMode);
    return;
  }

  setup_insight();
  let request = ++insightRequest;
  insightRepoName = repo_name;
  insightRepoPoint = point;
  insightID = ID;
  insightMode = insightSelectedMode;
  console.log("request e-insight: ", request, ID, insightMode, insightRequest);

  show_dialog(processing, 'fetch_insight', 'modal-robot', "fetch_insight(" + repo_name + ", " + ID + ", " + insightMode + ", " + request + ")");
  let response = await fetch("/json/expression-insight/?repo=" + encodeURIComponent(repo_name) + "&ID=" + ID + "&point=" + point + "&private=" + insightSelectedMode);
  if (request != insightRequest) { console.log("skip e-insight-1: ", request, insightRequest); return; }
  console.log("response e-insight: ", request, ID, insightMode, insightRequest);
  insightPages = await response.json();
  if (request != insightRequest) { console.log("skip e-insight-2: ", request, insightRequest); return; }
  // console.log(" => e-insight: ", request, insightPages.length); 
  remove_el('fetch_insight');
  insightCurrentPageIndex = 0;
  updateInsightContent();
  updateInsightNavigationButtons();
}

async function show_blockInsight(repo_name, point, ID) {
  if (insightRepoName == repo_name && insightRepoPoint == point && insightID == ("F" + ID) && insightMode == insightSelectedMode)
  {
    // console.log("skip, request f-insight: ", repo_name, point, ID, insightMode);
    return;
  }

  setup_insight();
  let request = ++insightRequest;
  insightRepoName = repo_name;
  insightRepoPoint = point;
  insightID = "F" + ID;
  insightMode = insightSelectedMode;
  // console.log("request f-insight: ", request, insightID, insightMode);

  if (insightSelectedMode != "option3") {
    insightPages = [{Id: 0, Insight: "Use Public mode to receive block Mentor Insights"}];
    insightCurrentPageIndex = 0;
    updateInsightContent();
    updateInsightNavigationButtons();
    return;
  }
  show_dialog(processing, 'fetch_insight', 'modal-robot', "fetch_insight(" + repo_name + ", " + ID + ")");
  let response = await fetch("/json/block-insight/?repo=" + encodeURIComponent(repo_name) + "&ID=" + ID + "&point=" + point);
  if (request != insightRequest) { console.log("f-insight-1: ", request, insightRequest); return; }
  insightPages = await response.json();
  if (request != insightRequest) { console.log("f-insight-2: ", request, insightRequest); return; }
  // console.log(" => f-insight: ", request, insightPages); 
  remove_el('fetch_insight');
  insightCurrentPageIndex = 0;
  updateInsightContent();
  updateInsightNavigationButtons();
}

function applyStylesToSelector(selector, property, value) {
  const elements = document.querySelectorAll(selector);

  for (const element of elements) {
    element.style[property] = value;
  }
}

async function updateInsightContent() {
  if (insightPages && insightCurrentPageIndex < insightPages.length) {
    document.getElementById('insight-page').innerText = (insightCurrentPageIndex + 1) + " / " + insightPages.length;
    var insight = insightPages[insightCurrentPageIndex];
    insightRoot.innerHTML = insight.Insight;
    const observer = new MutationObserver((mutations) => {
      applyStylesToSelector(".token.operator, .token.url", "background", "initial");
      applyStylesToSelector("pre", "background", "#741da330");
      applyStylesToSelector("pre", "border", "1px solid #666");
    });
    try {
      observer.observe(document.body, {
        childList: true,
        subtree: true,
      });
      Prism.highlightAllUnder(insightRoot);
    }
    catch (e) {
    }
    setTimeout(() => { observer.disconnect(); }, 5000);

    const Id = insight.Id;
    if (Id) {
      await fetch("/json/insight_view/?repo=" + encodeURIComponent(insightRepoName) + "&ID=" + Id + "&point=" + insightRepoPoint);
    }
  } else {
    insightRoot.innerHTML = "";
    document.getElementById('insight-page').innerText = "";
  }
};

function updateInsightNavigationButtons() {
  if (!insightPages || insightCurrentPageIndex <= 0) {
    // console.log("rec: prev: disabled", insightCurrentPageIndex, insightPages.length);
    insightPrevButton.classList.add("disabled");
  } else {
    // console.log("rec: prev: enabled", insightCurrentPageIndex, insightPages.length);
    insightPrevButton.classList.remove("disabled");
  }

  if (!insightPages || insightCurrentPageIndex >= insightPages.length - 1) {
    // console.log("rec: next: disabled", insightCurrentPageIndex, insightPages.length);
    insightNextButton.classList.add("disabled");
  } else {
    // console.log("rec: next: enabled", insightCurrentPageIndex, insightPages.length);
    insightNextButton.classList.remove("disabled");
  }
};

function rightChangeFlex(change) {
  const right = document.querySelector('.panel-right');
  const style = getComputedStyle(right);
  var newFlexGrow = Math.round((parseFloat(style.flexGrow) + change) * 4) / 4;
  if (newFlexGrow < 0.25) newFlexGrow = 0.25;
  right.style.flex = `${newFlexGrow} ${style.flexShrink} ${style.flexBasis}`;
  right.style.maxWidth = (100 * newFlexGrow / (2 + newFlexGrow)) + '%';
}

async function upVote() {
  const up = document.getElementById("up");
  const down = document.getElementById("down");
  up.classList.add('selected');
  down.classList.remove('selected');
  const Id = insightPages[insightCurrentPageIndex].Id;
  await fetch("/json/insight_up/?repo=" + encodeURIComponent(insightRepoName) + "&ID=" + Id + "&point=" + insightRepoPoint);
}

async function downVote() {
  const up = document.getElementById("up");
  const down = document.getElementById("down");
  up.classList.remove('selected');
  down.classList.add('selected');
  const Id = insightPages[insightCurrentPageIndex].Id;
  await fetch("/json/insight_down/?repo=" + encodeURIComponent(insightRepoName) + "&ID=" + Id + "&point=" + insightRepoPoint);
}

async function load_repo_report(repo_name) {
  replace_html('repo_report', "/partial/repo_report/?repo=" + encodeURIComponent(repo_name));
}

function toggle_privilege_checkboxes() {
  let user_role = document.getElementById('role')?.value ?? '';
  let use_default_privs = document.getElementById('use_default_privs');
  let privs = document.getElementsByClassName('user-priv');
  let disable_all = user_role == "admin" || user_role == "owner";
  let disabled = use_default_privs.checked || disable_all ? '-' : '';
  for (let priv of privs) {
    priv.disabled = disabled;
  }
  use_default_privs.disabled = disable_all ? '-' : '';
}

function toggle_repo_user_access() {
  let restricted = document.getElementById('restrict_repo_access').checked;
  let user_access_els = document.getElementsByClassName('user-access');
  let display = restricted ? '' : 'none';
  for (let el of user_access_els) {
    el.style.display = display;
  }
}

function add_user_access() {
  let user_select = document.getElementById('add-user-access');
  let user_id = parseInt(user_select.value);
  let user_name = user_select.options[user_select.selectedIndex].innerText;

  let access_list = document.getElementById('user-access-list');

  let old_size = repo_user_access.size;
  repo_user_access.add(user_id);

  if (repo_user_access.size !== old_size) {
    access_list.innerHTML += `
    <div class="user-tile" id="user-tile-${user_id}">
      ${user_name} <a class="user-tile-link" onclick="remove_user_access(${user_id})">❌</a>
    </div>
    `;
  }
}

function remove_user_access(user_id) {
  repo_user_access.delete(user_id);
  document.getElementById(`user-tile-${user_id}`).remove();
}

function post_repo_privs(repo_name, repo_form_data) {
  let restricted = repo_form_data.get('restrict_repo_access');
  let priv_data = JSON.stringify({
    'restricted': restricted,
    'user_access': Array.from(repo_user_access),
  });
  let post_url = `/repo-privs/post/${repo_name}`;
  let promise = fetch(post_url, { method: 'POST', body: priv_data });
  repo_user_access.clear();
  return promise;
}

function darken_rgb(rgb_str) {
  rgb_str = rgb_str.replace('rgb(', '').replace(')', '');
  let rgb = rgb_str.split(', ');

  if (rgb.length === 3) {
    let red = parseInt(rgb[0]);
    let green = parseInt(rgb[1]);
    let blue = parseInt(rgb[2]);

    let red_darker = Math.max(0, red - 80);
    let green_darker = Math.max(0, green - 80);
    let blue_darker = Math.max(0, blue - 80);

    return 'rgb(' + red_darker + ', ' + green_darker + ', ' + blue_darker + ')';
  } else {
    return '#999';
  }
}

function updateGrade() {
  // Get all score elements
  const scoreDivs = document.querySelectorAll('.score');

  scoreDivs.forEach(scoreDiv => {
    const container = scoreDiv.closest('.scoring_container');
    const gradeDiv = container.querySelector('.grade');
    
    const score = parseInt(scoreDiv.textContent.trim(), 10);

    let gradeText = '';
    let gradeClass = '';
    
    if (score >= 0 && score <= 500) {
        gradeText = 'Below Average';
        gradeClass = 'below-average';
    } else if(score >= 501 && score <= 600) {
        gradeText = 'Average';
        gradeClass = 'average';
    } else if(score >= 601 && score <= 650) {
        gradeText = 'Good';
        gradeClass = 'good';
    } else if(score >= 651 && score <= 750) {
        gradeText = 'Great';
        gradeClass = 'great';
    } else if(score >= 751 && score <= 800) {
        gradeText = 'Excellent';
        gradeClass = 'excellent';
    } else if(score >= 801 && score <= 1000) {
        gradeText = 'Outstanding';
        gradeClass = 'outstanding';
    }
    
    gradeDiv.textContent = gradeText;
    gradeDiv.className = `grade ${gradeClass}`; // reset and apply the new class
  });

  // TODO: remove when duplicated score on instance summaries is fixed
  if (window.location.href.split('/').length >= 7) {
    let report = document.querySelectorAll('.MMRR')[0];
  
    let header_count = 0;
    for (let i = 0; i < report.children.length; i++) {
      let el = report.children[i];
      if (el.tagName == 'H2') {
        if (el.textContent.includes('Lifetime')) {
          return;
        }
        
        header_count += 1;
      }
      if (header_count >= 3) {
        el.style.display = 'none';
      }
    }
  }
}

function toggle_menu() {
  let hamburger_menu_links = document.getElementById("hamburger-menu-links");
  let display = hamburger_menu_links.style.display;
  display = display === 'none' || display.length === 0 ? 'block' : 'none';
  hamburger_menu_links.style.display = display;
}

function set_tab(id) {
  var curr_tab_button = document.getElementById(id);
  var prev_tab_button = document.getElementById(curr_tab_id);
  curr_tab_button.classList.toggle("selected-tab");
  prev_tab_button.classList.toggle("selected-tab");
  curr_tab_id = id;
}

function toggle_compare_selection(repo_name) {
  compare_selections.has(repo_name) ?
    compare_selections.delete(repo_name) :
    compare_selections.add(repo_name);

  let checkboxes = document.getElementsByClassName('rl-compare-checkbox');
  for (let checkbox of checkboxes) {
    checkbox.disabled = compare_selections.size === 2 && !checkbox.checked;
  }
  toggle_compare_popup(compare_selections.size >= 1);
}

function toggle_compare_popup(show) {
  let popup = document.getElementById('compare-popup');
  popup.style.display = show ? 'flex' : 'none';

  let middles = document.getElementsByClassName('middle');
  if (middles.length > 0) {
    middles[0].style.marginBottom = show ? '64px' : '0';
  }

  let sorted_repos = Array.from(compare_selections);
  sorted_repos.sort((a, b) => a.toLowerCase() > b.toLowerCase());

  popup.children[2].innerHTML = 'Selected Repositories: ';
  for (let i = 0; i < sorted_repos.length; i++) {
    popup.children[2].innerHTML += sorted_repos[i];
    if (i < sorted_repos.length - 1) {
      popup.children[2].innerHTML += ', ';
    }
  }

  let compare_button = document.getElementById('compare-button');
  if (compare_button) compare_button.disabled = compare_selections.size < 2;
}

function compare_repos() {
  if (compare_selections.size == 2) {
    let sorted_repos = Array.from(compare_selections);
    sorted_repos.sort((a, b) => a.toLowerCase() > b.toLowerCase());

    let repo1 = sorted_repos[0];
    let repo2 = sorted_repos[1];

    let req_href = "/repo_compare?repo1=" + encodeURIComponent(repo1) + "&repo2=" + encodeURIComponent(repo2);
    
    window.location.href = req_href;
  }
}

function cancel_compare_repos() {
  compare_selections.clear();
  toggle_compare_popup(false);

  let checkboxes = document.getElementsByClassName('rl-compare-checkbox');
  for (let checkbox of checkboxes) {
    checkbox.checked = false;
    checkbox.disabled = false;
  }
}

function format_date(id) {
  let date_el = document.getElementById(id);
  if (date_el.innerText != 'N/A') {
    let date = new Date(date_el.innerText);
    date_el.innerText = date.toLocaleString();
  }
}

function setup_repo_search() {
  let search_field = document.getElementById('repo-search');
  if (search_field) search_field.addEventListener("input", function () { repo_search(); } );
}

function setup_repo_score_filter() {
  let score_min = document.getElementById("score-filter-min");
  let score_max = document.getElementById("score-filter-max");
  if (score_min) score_min.addEventListener("input", function () { repo_score_filter(); });
  if (score_max) score_max.addEventListener("input", function () { repo_score_filter(); })
}

function setup_repo_language_filter() {
  let checkboxes = document.querySelectorAll('.lang-checkbox input');
  for (let checkbox of checkboxes) {
    let name_split = checkbox.name.split("-");
    let lang = name_split[name_split.length - 1];
    checkbox.addEventListener('change', function () { repo_language_filter(lang); } );
  }
}

function reset_repo_search_and_filters() {
  selected_languages = new Set();
  repo_search_results = new Set();
  repo_score_filter_results = new Set();
  repo_language_filter_results = new Set();
  show_hide_repo_rows();
}

function repo_search() {
  let search_field = document.getElementById('repo-search');
  search_text = search_field ? search_field.value : '';
  for (const [repo_row_id, repo_name] of Object.entries(repo_search_entries)) {
    let show = repo_name.toLowerCase().startsWith(search_text.toLowerCase());
    repo_search_results[repo_row_id] = show;
  }

  show_hide_repo_rows();
}

function repo_score_filter() {
  let score_min = parseInt(document.getElementById('score-filter-min').value);
  let score_max = parseInt(document.getElementById('score-filter-max').value);
  let score_min_label = document.getElementById('score-filter-min-label');
  let score_max_label = document.getElementById('score-filter-max-label');

  score_min_label.innerText = "Min: " + score_min.toString();
  score_max_label.innerText = "Max: " + score_max.toString();

  for (let [repo_row_id, repo_score] of Object.entries(repo_score_filter_entries)) {
    repo_score = parseInt(repo_score);

    let show = (repo_score >= score_min && repo_score <= score_max) ||
      (repo_score === -1 && score_min === 300);
    
    repo_score_filter_results[repo_row_id] = show;
  }

  show_hide_repo_rows();
}

function repo_language_filter(lang) {
  selected_languages.has(lang) ?
    selected_languages.delete(lang) :
    selected_languages.add(lang);
  
  for (const [repo_row_id, repo_lang] of Object.entries(repo_language_filter_entries)) {
    let show = selected_languages.has(repo_lang);
    repo_language_filter_results[repo_row_id] = show;
  }

  show_hide_repo_rows();
}

function show_hide_repo_rows() {
  for (let repo_row_id of repo_row_ids) {
    let show = true;
    if (repo_row_id in repo_search_results) {
      show = show && repo_search_results[repo_row_id];
    }
    if (repo_row_id in repo_score_filter_results) {
      show = show && repo_score_filter_results[repo_row_id];
    }
    if (selected_languages.size > 0 && repo_row_id in repo_language_filter_results) {
      show = show && repo_language_filter_results[repo_row_id];
    }
    let row = document.getElementById(repo_row_id);
    if (row) row.style.display = show ? 'block' : 'none';
  }

  for (let chart of repo_list_charts) {
    chart.resize();
  }
}

function add_repo_search_entry(repo_row_id, repo_name) {
  repo_search_entries[repo_row_id] = repo_name;
  repo_row_ids.add(repo_row_id);
}

function add_repo_score_filter_entry(repo_row_id, score) {
  repo_score_filter_entries[repo_row_id] = score;
}

function add_repo_language_filter_entry(repo_row_id, language) {
  repo_language_filter_entries[repo_row_id] = language;
}

function toggle_filter_options() {
  let filter_options = document.getElementById('repo-filters');
  if (filter_options) {
    let is_visible = filter_options.style.display !== 'none';
    filter_options.style.display = is_visible ? 'none' : 'block';
  }
}

function toggle_lang_checkbox(id) {
  let checkbox = document.querySelector('#' + id + ' input');
  if (checkbox) {
    checkbox.checked = !checkbox.checked;
    let name_split = id.split("-");
    let lang = name_split[name_split.length - 1];
    repo_language_filter(lang);
  }
}
